    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
     */
    package program2;


    // Programmer: Hirna Panchal 12203921
    // File: Program2.java
    // Date: November 14, 2022
    // Purpose: COIT11222 assignment two question two T322
    // Input of datatype and arithmetics expressions

        import java.util.Scanner;

        public class Program2{

        public static void main(String[] args) {

            //Ask the user for name input
            Scanner inText = new Scanner(System.in);
            System.out.print("Please enter the booking name ==>");

            //Read the name of Customer
            String bookingName = inText.nextLine();




            Scanner inNumber = new Scanner(System.in);
            System.out.print("\nEnter the number of nights for "+bookingName+ "==>");

            //Read the number of nights
             int bookingNights = inNumber.nextInt();
            System.out.println("\n \n\n--- Yepoon Cabins Reciept---");
            System.out.println("Booking Name: " + bookingName);
            System.out.println("Number of nights: " + bookingNights );
            final double NIGHTLY_CHARGE =89.95;
            final double CLEANING_CHARGE =20.00;

            final double charge = (bookingNights * NIGHTLY_CHARGE) + CLEANING_CHARGE ;

            System.out.printf("Total charge: $" +charge);

        }

    }
