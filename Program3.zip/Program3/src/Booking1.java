    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */

    // Programmer: Hirna Panchal 12203921
    // File: Booking1.java
    // Date: January 3, 2023
    // Purpose: COIT11222 assignment one question three 
    // Creating  class to Represent Booking

    public class Booking1 {
    //Create main class as Booking1

        //two private instance
        private String bookingName; //string for name of the booking

        private int nights; //int for number of nights

        // create a Booking class to get total charge 
        //default constructor
        public Booking1(String bookingName, int nights) {
            this.bookingName = bookingName;
               this.nights = nights; 

        //return total charge

    }
        //creating get and set methods

        //set method for bookingName
        public void setbookingName(String bookingName) {
            this.bookingName = bookingName;
        }

        //set method for number of nights
        public void setnights(int nights) {
            this.nights = nights;
        }

        //get method for bookingName
        public String getbookingName() {
            return bookingName;
        }

        //get method for number of nights
        public int getnights() {
            return nights;
        }

        // create a calculator header  to calculate night and charge
        public double calculateCharge(String bookingName, int nights ){
            final double Nightly_charge = 89.95;
            final double Cleaning_charge = 20.00;

            double Total_charge = (Nightly_charge * nights) + Cleaning_charge; // calcuation total price

        //display the final results    
            System.out.println("\n---yeppoon Cabin Receipt---");

        //Display booking name, String
            System.out.println("Booking name : "+bookingName);

        //Display booking nights, int
            System.out.println("Number of nights: "+nights);

        //Display  total charge, final double
            System.out.printf("total charge :%.2f\n", Total_charge);

        //return 
            return 0;



        }
    }
