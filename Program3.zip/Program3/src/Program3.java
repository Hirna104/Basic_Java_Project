
//import static Booking1.calculateCharge;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
// Programmer: Hirna Panchal 12203921
// File: Program3.java
// Date: January 3, 2023
// Purpose: COIT11222 assignment one question three 
// create a client class Program3
import java.util.Scanner;
public class Program3 {

    
    public static void main(String[] args) {
        
       // create a scanner object to manage console input
        Scanner Bookingname = new Scanner(System.in); 
       
        // get input for bookingName, String
        System.out.printf("Please enter your name: ");

        //reading bookingName
        String Username = Bookingname.nextLine();          
        
        Scanner inNumber = new Scanner(System.in);  
        
        // get number of nights, int
        System.out.printf("\nenter the numbers of nights for " + Username + " ==> "); 

        int night = inNumber.nextInt(); 
        
        Booking1 myobj = new Booking1(Username, night);
        
        // create a calculator object to calculate total charge
          myobj.calculateCharge(Username, night);

        

        }

   
        
}