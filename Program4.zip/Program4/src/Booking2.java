/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// Programmer: Hirna Panchal 12203921
// File: Booking2.java
// Date: January 3, 2023
// Purpose: COIT11222 assignment one question four 
// Creating  class to Represent Booking

public class Booking2 {
//Create main class as Booking2
    
    //declaring variables 
    
    //declaring bookingName, String
    private String bookingName; 

    //declaring nights, int
    private int nights; 
    
    //
    public Booking2(String bookingName, int nights) {
        this.bookingName = bookingName;
           this.nights = nights; 
           
         
//        return Total_charge;
}
    // using mutators and accessors 
    
    //two set methods
    //one for bookingName, String
    //two for nights, int
    public void setbookingName(String bookingName) {
        this.bookingName = bookingName;
    }

    public void setnights(int nights) {
        this.nights = nights;
    }
    
    //two get methods
    //one for bookingName, String 
    //two for nights, int
    public String getbookingName() {
        return bookingName;
    }

    public int getnights() {
        return nights;
    }
    
    //create calculator header
    public double calculateCharge(String bookingName, int nights ){
        final double Nightly_charge = 89.95;
        final double Cleaning_charge = 20.00;
        double Total_charge;
        
    //Calculate total charge using the logic
    //Total_charge = (Nightly_charge * nights) + Cleaning_charge, double
   
    //using if statement giving the discounts
    
    //if nights expands more than 7 nights then 10% discount
    if(nights > 7){
        
    //calculate total charge after discount,10%
             Total_charge = (Nightly_charge * nights *0.90) + Cleaning_charge; 
    
}

    //else if nights expands more than 14 than 15% discount
    else if(nights > 14){
        
    //calculate total charge after discount,15%
             Total_charge = (Nightly_charge * nights *0.85) + Cleaning_charge; 
}
    //else no discount
    else{
        
    //else normal charges without any discount
             Total_charge = (Nightly_charge * nights) + Cleaning_charge; // calcuation total price

}
    //final outcome
   
        System.out.println("\n---yeppoon Cabin Receipt---");

    //bookingName, String
        System.out.println("Booking name : "+bookingName);

    //nights, int
        System.out.println("Number of nights: "+nights);
        
    //total charge, double
        System.out.printf("total charge :%.2f\n", Total_charge);
        
    //return 
        return 0;
    }
    
    
}
