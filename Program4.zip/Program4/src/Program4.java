/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

// Programmer: Hirna Panchal 12203921
// File: Program4.java
// Date: January 3, 2023
// Purpose: COIT11222 assignment one question four 


//create a client class Program4
import java.util.Scanner;
public class Program4 {

    
    public static void main(String[] args) {
       
        // create a scanner object to manage console input
        Scanner Bookingname = new Scanner(System.in); 

        // get input for bookingName, String
        System.out.printf("Please enter your name: "); 

        //reading bookingName, String
        String Username = Bookingname.nextLine();            
        
        // create a scanner object to manage console input
        Scanner inNumber = new Scanner(System.in);  

         // get number of nights, int
        System.out.printf("\nenter the numbers of nights for " + Username + " ==> ");

        //reading nights, int
        int night = inNumber.nextInt(); 
        
        Booking2 myobj = new Booking2(Username, night);
        
        // create a calculator object to calculate total charge
          myobj.calculateCharge(Username, night);

    }
    
}
