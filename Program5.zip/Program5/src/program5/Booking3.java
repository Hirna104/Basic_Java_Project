/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program5;

/**
 *
 * @author hirnapanchal
 */
       // Programmer: Hirna Panchal 12203921
        // File: Program5.java
        // Date: December 12, 2022
        // Purpose: COIT11222 assignment one question 5 
        // Use Repetition statements
public class Booking3 {
    
      private String bookingName; // declaring private variables, string

    private int nights; // declaring variable as private integers
//    private Object[] Total_charge;

    public Booking3(String bookingName, int nights) {
        this.bookingName = bookingName;
           this.nights = nights; 
           
         
//        return Total_charge;
}

    public void setbookingName(String bookingName) {
        this.bookingName = bookingName;
    }

    public void setnights(int nights) {
        this.nights = nights;
    }

    public String getbookingName() {
        return bookingName;
    }

    public int getnights() {
        return nights;
    }
    public double calculateCharge(String bookingName, int nights ){
        final double Nightly_charge = 89.95;
        final double Cleaning_charge = 20.00;
        double Total_charge;
        
//         double Total_charge = (Nightly_charge * nights) + Cleaning_charge; // calcuation total price
if(nights > 14){
             Total_charge = (Nightly_charge * nights *0.85) + Cleaning_charge; // calcuation total price
}else if(nights > 7){
             Total_charge = (Nightly_charge * nights *0.90) + Cleaning_charge; // calcuation total price
}else{
             Total_charge = (Nightly_charge * nights) + Cleaning_charge; // calcuation total price

}
         //final display
        System.out.println("\n---yeppoon Cabin Receipt---");
//        String bookingName = null;
        System.out.println("Booking name : "+bookingName);
//        String nights = null;
        System.out.println("Number of nights: "+nights);
        
        System.out.printf("total charge :%.2f\n", Total_charge);
        
        return 0;
    }
    
    
}
