/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package program5;

import java.util.Scanner;

/**
 *
 * @author hirnapanchal
 */
public class Program5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          Scanner Bookingname = new Scanner(System.in);  // Create a Scanner object

        System.out.printf("Please enter your name: "); // requesting for input

        String Username = Bookingname.nextLine();            // reading customer name
        
        while(Username =="" ){
                System.out.println("Error booking name can't be blank");
         
         System.out.printf("Please enter your name: "); // requesting for input
         Username = Bookingname.nextLine();
            
        }
        
        Scanner inNumber = new Scanner(System.in);  //creating new scanner object

        System.out.printf("\nenter the numbers of nights for " + Username + " ==> "); //requesting for number of nights to stay

        int night = inNumber.nextInt(); //reading customer number of nights
        
        while(night <=0 ){
                System.out.println("Error number of nights must be greater than or equal to 1");
         
         System.out.printf("\nenter the numbers of nights for " + Username + " ==> "); // requesting for input
         night = inNumber.nextInt();
            
        }
        Booking3 myobj = new Booking3(Username, night);
        
          myobj.calculateCharge(Username, night);

    }
    
}
